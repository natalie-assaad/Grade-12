package monkeyGame;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
* This program runs the startsScreen which allows the user
* to view instructions on how to play the game, quit, and
* select between either Normal or Hard mode.
*
* @author  Natalie Assaad
* @version 1.0
* @since   2018-12-12
*/
public class startScreenController {

	Stage secondaryStage = new Stage();
	
	@FXML
	private MenuButton menuButton;
	
	/**
	* This method handles menu input
	* @param evt An Event object that represents an event
	*/
	public void menuClickHandler(ActionEvent evt) {
		MenuItem clickedMenu = (MenuItem) evt.getTarget();
		String menuLabel = clickedMenu.getText();
		
		if ("Normal Mode".equals(menuLabel)) {
			closeCurrentWindow(evt);
			openNormalModeWindow(secondaryStage);
		} else if ("Hard Mode".equals(menuLabel)) {
			closeCurrentWindow(evt);
			openHardModeWindow(secondaryStage);
		}
	}

	/**
	* This method handles button input
	* @param evt An Event object that represents an event
	*/
	public void buttonClickHandler (ActionEvent evt) {
		Button clickedButton = (Button) evt.getTarget();
		String buttonLabel = clickedButton.getText();
		
		if ("Instructions".equals(buttonLabel)) {
			openInstructWindow();
		} else if ("Quit".equals(buttonLabel)) {
			Main.quitWindow();
		}
	}
	
	private void openNormalModeWindow(Stage secondaryStage) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("monkeyGame.fxml"));
			BorderPane root = (BorderPane)loader.load();
			Scene scene = new Scene(root,1000,700);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			monkeyGameController controller = loader.getController();
			secondaryStage.setScene(scene);
			controller.getScene(secondaryStage);
			controller.gameLoop();
			secondaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private void openHardModeWindow(Stage secondaryStage) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("monkeyHardGame.fxml"));
			BorderPane root = (BorderPane)loader.load();
			Scene scene = new Scene(root,1000,700);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			monkeyHardGameController controller = loader.getController();
			secondaryStage.setScene(scene);
			controller.getScene(secondaryStage);
			controller.gameLoop();
			secondaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private void openInstructWindow() {
		try {
				
			// loads the instructions pop up
			Pane howTo = (Pane)FXMLLoader.load(getClass().getResource("Instructions.fxml"));
					
			// creates a new scene
			Scene howToScene = new Scene(howTo,300,337);

			// adds css to the new scene		
			howToScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			//creates new stage to put scene in
			secondaryStage = new Stage();
			secondaryStage.setScene(howToScene);
			secondaryStage.setResizable(false);
			secondaryStage.show();
				
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	* This method closes the start screen once the user selects a game mode
	* @param evt An Event object that represents an event
	*/
	public void closeWindowButtonClickHandler(ActionEvent evt) {
		secondaryStage.close();
	}
	
	private void closeCurrentWindow(ActionEvent evt) {
		Stage stage = (Stage) menuButton.getScene().getWindow();
		stage.close();
	}

}