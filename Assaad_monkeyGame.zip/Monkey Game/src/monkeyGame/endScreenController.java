package monkeyGame;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
* This program runs the endScreen which allows the user
* to view how many points they earned, play the game again, 
* or quit
*
* @author  Natalie Assaad
* @version 1.0
* @since   2018-12-12
*/
public class endScreenController {

	Stage secondaryStage = new Stage();
	
	@FXML
	private FXMLLoader loader;
	
	@FXML
	private Text printScore;
	
	@FXML
	private Scene endScene;
	
	@FXML
	GraphicsContext gc;
	
	@FXML
    Canvas gameCanvas;

	/**
	* This method handles button input
	* @param evt An Event object that represents an event
	*/
	public void buttonClickHandler (ActionEvent evt) {
		Button clickedButton = (Button) evt.getTarget();
		String buttonLabel = clickedButton.getText();
		
		if ("Play Again".equals(buttonLabel)) {
			closeCurrentWindow(evt);
			openStartGameWindow();
		} else if ("Quit".equals(buttonLabel)) {
			Main.quitWindow();
		}
	}
	
	public void displayScore() {
		printScore.setText(String.valueOf(Banana.eaten));
	}
	
	private void openStartGameWindow() {
		try {
			
			Monkey monkey = new Monkey(gc, gameCanvas);
			
			 Banana.eaten = 0;
			 monkey.lives = 3;
			
			// loads the instructions pop up
			Pane howTo = (Pane)FXMLLoader.load(getClass().getResource("startScreen.fxml"));
					
			// creates a new scene
			Scene howToScene = new Scene(howTo,600,400);

			// adds css to the new scene		
			howToScene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			//creates new stage to put scene in
			secondaryStage.setScene(howToScene);
			secondaryStage.setResizable(false);
			secondaryStage.show();
				
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	* This method closes the start screen once the user selects a game mode
	* @param evt An Event object that represents an event
	*/
	public void closeWindowButtonClickHandler(ActionEvent evt) {
		secondaryStage.close();
	}
	
	private void closeCurrentWindow(ActionEvent evt) {
		final Node source = (Node) evt.getSource();
		final Stage stage =(Stage)source.getScene().getWindow();
		stage.close();
	}

}