package monkeyGame;

import java.util.ArrayList;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
* The monkeyGameController class runs the hard mode of Monkey Game
*
* @author  Natalie Assaad
* @version 1.0
* @since   2018-12-12
*/
public class monkeyHardGameController {

	@FXML
	Canvas gameCanvas;
	Scene gameScene;
	GraphicsContext gc;
	
	Stage secondaryStage = new Stage();
	
	ArrayList<Coconut> coconutList = new ArrayList<Coconut>();
	ArrayList<String> input = new ArrayList<String>(); // key input arrayList
	
	private boolean displayShoe = false;
	private boolean addCoconut = false;
	private boolean coconutAlreadySent = false;
	
	private long startTime = 0;
	private long currentTime = 0;
	private long elapsedTime = 0;

	/**
	   * This method gets the scene
	   * @param secondaryStage The new stage that opens once the user picks a mode
	   */
	public void getScene(Stage secondaryStage) {
		gameScene = secondaryStage.getScene();
	}
	
	/**
	   * This method runs the game loop and handles object collision, key input, and animation
	   */
    public void gameLoop() {

    	// handles key input
    	gameScene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent e) {
                String code = e.getCode().toString();
                if (!input.contains(code))
                    input.add(code);
            }
        });

        gameScene.setOnKeyReleased(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent e) {
                String code = e.getCode().toString();
                if (input.contains(code))
                    input.remove(code);
            }
        });
        
		gc = gameCanvas.getGraphicsContext2D(); // initialize the canvas for 2D drawing
		
		Image background = new Image("images/background.png"); // loads background image
		// allows code to access methods from other files
		Monkey monkey = new Monkey(gc, gameCanvas);
		Banana banana = new Banana(gc, gameCanvas);
		Score score = new Score(gc, gameCanvas);
		Shoe shoe = new Shoe(gc, gameCanvas);
		Coconut coconut = new Coconut(gc, gameCanvas);
		badBanana badBanana = new badBanana(gc, gameCanvas);
		Portal portal = new Portal(gc, gameCanvas);
		
		new AnimationTimer() {
					
			// actual game loop that repeats
			@Override
			public void handle(long currentNanoTime) { // repeat at 60 frames per second
				
				// clear the whole canvas each frame
				gc.clearRect(0, 0, gameCanvas.getWidth(), gameCanvas.getHeight());
				
				gc.drawImage(background, 0, 0);
								
				monkey.move(input);
				
				banana.drawBanana();
				
				portal.drawPortal();
				
				score.display(monkey);
				
				badBanana.drawBanana();
				
				if (displayShoe == true) {
					shoe.drawShoe();
					currentTime = System.currentTimeMillis();
					elapsedTime = currentTime - startTime;
					if (elapsedTime > 5000) {
						displayShoe = false;
					}
				}
				
				if (Banana.eaten % 3 == 0 && Banana.eaten > 1 && coconutAlreadySent == false) {
					addCoconut = true;
					Banana.eaten += 1;
				}
				
		    	if (addCoconut) {
			    	coconut.numCoconuts += 1;
					coconutList.add(new Coconut(gc,gameCanvas));
					addCoconut = false;
		    	}
		    	
		    	// Collision Detection --------------------------------------
				for (int i = 0; i < coconut.numCoconuts; i++) {
					coconutList.get(i).move();
					boolean coconutCollide = monkey.collisionCoconut(coconutList.get(i));
					if (coconutCollide) {
						monkey.hitCoconut(coconutList.get(i));
						if (monkey.lives == 0) {
							final Stage stage = (Stage)gameScene.getWindow();
							stage.close();
							openEndScreen(secondaryStage);
						}
					}
				}
			
				boolean bananaCollide = monkey.collisionBanana(banana);
				if (bananaCollide) {
					monkey.hitBanana(banana); // moves banana to new location upon impact
					displayShoe = true;
					startTime = System.currentTimeMillis();
					shoe.newXnewY();
					bananaCollide = false;
				}
				
				boolean badBananaCollide = monkey.collisionBadBanana(badBanana);
				if (badBananaCollide) {
					monkey.hitBadBanana(badBanana);
					badBanana.newLocation();
				}
				
				boolean shoeCollide = monkey.collisionShoe(shoe);
				if (shoeCollide) {
					monkey.speedBoost();
					displayShoe = false;
				}
				
				boolean portalCollide = monkey.collisionPortal(portal);
				if (portalCollide) {
					monkey.teleport();
				}
			
		    }
			
		}.start();
		
	}	
    
    private void openEndScreen(Stage secondaryStage) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("endScreen.fxml"));
			BorderPane root = (BorderPane)loader.load();
			Scene scene = new Scene(root,300,300);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			endScreenController endScreen = loader.getController();
			endScreen.displayScore(); // this calls the method to print the score
	    	
			secondaryStage.setScene(scene);
			secondaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
    }
	
}
