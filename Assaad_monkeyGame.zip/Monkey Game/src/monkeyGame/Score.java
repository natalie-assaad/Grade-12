package monkeyGame;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * This method controls the score which displays the number of lives left as well
 * as the score the user has managed to get throughout the game
 * @author  Natalie Assaad
 * @version 1.0
 * @since   2018-11-26
 */
public class Score {
	
	@FXML
	GraphicsContext gc;
	
	@FXML
    Canvas gameCanvas;
	
	/**
	   * This method is a constructor method that takes the graphics context and the canvas
	   * set by the programmer and sets it equal to the relevant objects initialized at the start of the program.
	   * @param gc The graphics context calls to a Canvas using a buffer
	   * @param canvas The canvas is an image that can be drawn on using a set of graphics commands provided by a GraphicsContext
	   */	
    public Score(GraphicsContext gc, Canvas canvas) {
        super();
        this.gc = gc;
        this.gameCanvas = canvas;
    }
	
    /**
	   * This method is a constructor method that takes the graphics context and the canvas
	   * set by the programmer and sets it equal to the relevant objects initialized at the start of the program.
	   * @param monkey The monkey is an object that the user controls
	   */
	public void display(Monkey monkey){
		try {
		    String scoreStr = "Score: "+ String.valueOf(Banana.eaten);
		    gc.setFont(Font.font("ComicSansMS",FontWeight.BOLD,36));
		    gc.setFill(Color.RED);
		    gc.fillText(scoreStr, 20, 50);
		        
		    String livesStr = "Lives: " + String.valueOf(monkey.getLives());
		    gc.setFill(Color.RED);
		    gc.fillText(livesStr, 200, 50);
		    
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
