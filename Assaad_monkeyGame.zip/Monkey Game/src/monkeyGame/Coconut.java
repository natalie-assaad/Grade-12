package monkeyGame;

// imports
import javafx.fxml.FXML;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/**
 * This method controls the coconuts which is an object that, when it collides with the monkey (the object
 * the user controls) places the monkey at a random x and y coordinate on the canvas and causes the user to
 * lose a life
 * 
 * @author  Natalie Assaad
 * @version 1.0
 * @since   2018-11-26
 */
public class Coconut {    
    
    int speed = 3;
    double x = (int)(Math.random()*800) + 100;
    double y = (int)(Math.random()*500) + 100;
    double dx = (int)(Math.random()*5) - 5;
    double dy = - (int)(Math.random()*5) + 5;
    String imageName = "images/coconut.png";
    Image image = new Image(imageName);
    GraphicsContext gc;
    
    /** initializes public integer variable */
	public int numCoconuts = 0;
    
    @FXML
    Canvas gameCanvas;
    
    /**
	   * This method is a constructor method that takes the graphics context and the canvas
	   * set by the programmer and sets it equal to the relevant objects initialized at the start of the program.
	   * @param gc The graphics context calls to a Canvas using a buffer
	   * @param canvas The canvas is an image that can be drawn on using a set of graphics commands provided by a GraphicsContext
	   */
    public Coconut(GraphicsContext gc, Canvas canvas) {
        super();
        this.gc = gc;
        this.gameCanvas = canvas;
    }

    /**
	   * This method is a constructor method that takes the image name, graphics context and the canvas
	   * set by the programmer and sets it equal to the relevant objects initialized at the start of the program.
	   * @param imageName The imageName is a string that holds the path to the image
	   * @param gc The graphics context calls to a Canvas using a buffer
	   * @param canvas The canvas is an image that can be drawn on using a set of graphics commands provided by a GraphicsContext
	   */
    public Coconut(String imageName, GraphicsContext gc, Canvas canvas) {
        super();
        this.imageName = imageName;
        this.gc = gc;
        this.gameCanvas = canvas;
    }

    /**
	   * This method returns the speed value
	   * @return speed The speed is the rate at which someone or something is able to move or operate
	   */
    public int getSpeed() {
        return speed;
    }

    /**
	   * This method sets the speed value to the provided value
	   * @return speed The speed is the rate at which someone or something is able to move or operate
	   */
    public void setSpeed(int speed) {
        this.speed = speed;
    }

    /**
	   * This method returns the x value
	   * @return x The x value is the horizontal value in a pair of coordinates
	   */
    public double getX() {
        return x;
    }

    /**
	   * This method sets the x value to the provided value
	   * @param x The x value is the horizontal value in a pair of coordinates
	   */
    public void setX(double x) {
        this.x = x;
    }

    /**
	   * This method returns the y value
	   * @return y The y value is the vertical value in a pair of coordinates
	   */
    public double getY() {
        return y;
    }

    /**
	   * This method sets the y value to the provided value
	   * @param y The y value is the vertical value in a pair of coordinates
	   */
    public void setY(double y) {
        this.y = y;
    }

    /**
	   * This method returns the dx value
	   * @return dx The dx value is the value at which x changes left / right
	   */
    public double getDx() {
        return dx;
    }

    /**
	   * This method sets the y value to the provided value
	   * @param dx The dx value is the value at which x changes left / right
	   */
    public void setDx(double dx) {
        this.dx = dx;
    }

    /**
	   * This method returns the dy value
	   * @return dy The dy value is the value at which y changes up / down
	   */
    public double getDy() {
        return dy;
    }

    /**
	   * This method sets the dy value to the provided value
	   * @param dy The dy value is the value at which y changes up / down
	   */
    public void setDy(double dy) {
        this.dy = dy;
    }
    
    /**
	   * This method returns the width value
	   * @return image.getWidth() The width value is the measurement or extent of something from side to side
	   */
    public double getWidth() {
    	return image.getWidth();
    }
    
    /**
	   * This method returns the height value
	   * @return image.getHeight() The height value is the measurement or extent of something from top to bottom
	   */
    public double getHeight() {
    	return image.getHeight();
    }

    /**
	   * This method returns the string of the image name
	   * @return imageName The imageName is a string that contains the route used to access an image
	   */
    public String getImageName() {
        return imageName;
    }

    /**
	   * This method sets the string of the imageName to the provided value
	   * @param imageName The imageName is a string that contains the route used to access an image
	   */
    public void setImageName(String imageName) {
        this.imageName = imageName;
    }
    
    /**
	   * This method returns the value of numCoconuts
	   * @return numCoconuts The numCoconuts value is the number of coconuts drawn on the canvas
	   */
    public int getNumCoconuts() {
		return numCoconuts;
    }
    
    /**
	   * This method sets the value of numCoconuts to the provided value
	   * @param numCoconuts The numCoconuts value is the number of coconuts drawn on the canvas
	   * @return numCoconuts The numCoconuts value is the number of coconuts drawn on the canvas
	   */
    public int setNumCoconuts(int numCoconuts) {
    	return this.numCoconuts = numCoconuts;
    }
       
    /**
	   * This method contains all code to move and display an image
	   */
    public void move() {
    	this.x += this.dx;
        this.y += this.dy;
        
        if (this.x <= 0 ||this.x >= this.gameCanvas.getWidth() - this.image.getWidth()) {
            this.dx = -this.dx;
            //System.out.println("DX: " + this.dx);
        }
        if (this.y <= 0||this.y >= this.gameCanvas.getHeight() - this.image.getHeight()) {
            this.dy = -this.dy;
            //System.out.println("DY: " + this.dy + "\n");
        }
        this.gc.drawImage(this.image, this.x, this.y);
    }
    
    /**
	   * This method gets the boundary of the object
	   * @return Rectangle2D The Rectangle2D is used to describe the bounds of an object
	   */
    public Rectangle2D getBoundary() {
		return new Rectangle2D(this.x, this.y, this.image.getWidth(), this.image.getHeight());
    }

}

