package monkeyGame;

import java.util.ArrayList;
import javafx.fxml.FXML;
import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import monkeyGame.Banana;
import monkeyGame.Coconut;

/**
 * This method controls the monkey which is the object that the user controls,
 * and is the basis for all collision
 * @author  Natalie Assaad
 * @version 1.0
 * @since   2018-11-26
 */
public class Monkey {
	
	private String left = "LEFT";
	private String right = "RIGHT";
	private String up = "UP";
	private String down = "DOWN";
	private double dx = 1;
	private double dy = 1;
	private double speed = 2; 
	private double x = 500;
	private double y = 350;
	private String imageName = "images/monkey.png";
	private Image image = new Image(imageName);
	
	/** initializes public integer variable */
	public int lives = 3;
	
	@FXML
	GraphicsContext gc;

    @FXML
    Canvas gameCanvas;
	
	// key input arrayList
	ArrayList<String> input = new ArrayList<String>();
	
	/**
	   * This method is a constructor method that takes the graphics context and the canvas
	   * set by the programmer and sets it equal to the relevant objects initialized at the start of the program.
	   * @param gc The graphics context calls to a Canvas using a buffer
	   * @param canvas The canvas is an image that can be drawn on using a set of graphics commands provided by a GraphicsContext
	   */
    public Monkey(GraphicsContext gc, Canvas canvas) {
        super();
        this.gc = gc;
        this.gameCanvas = canvas;
    }

    /**
	   * This method is a constructor method that takes the image name, graphics context and the canvas
	   * set by the programmer and sets it equal to the relevant objects initialized at the start of the program.
	   * @param imageName The imageName is a string that holds the path to the image
	   * @param gc The graphics context calls to a Canvas using a buffer
	   * @param canvas The canvas is an image that can be drawn on using a set of graphics commands provided by a GraphicsContext
	   */
    public Monkey(String imageName, GraphicsContext gc, Canvas canvas) {
        super();
        this.imageName = imageName;
        this.gc = gc;
        this.gameCanvas = canvas;
    }

    /**
	   * This method returns the speed value
	   * @return speed The speed is the rate at which someone or something is able to move or operate
	   */
    public double getSpeed() {
        return speed;
    }

    /**
	   * This method sets the speed value to the provided value
	   * @return speed The speed is the rate at which someone or something is able to move or operate
	   */
    public void setSpeed(int speed) {
        this.speed = speed;
    }

    /**
	   * This method returns the x value
	   * @return x The x value is the horizontal value in a pair of coordinates
	   */
    public double getX() {
        return x;
    }

    /**
	   * This method sets the x value to the provided value
	   * @param x The x value is the horizontal value in a pair of coordinates
	   */
    public void setX(double x) {
        this.x = x;
    }

    /**
	   * This method returns the y value
	   * @return y The y value is the vertical value in a pair of coordinates
	   */
    public double getY() {
        return y;
    }

    /**
	   * This method sets the y value to the provided value
	   * @param y The y value is the vertical value in a pair of coordinates
	   */
    public void setY(double y) {
        this.y = y;
    }

    /**
	   * This method returns the dx value
	   * @return dx The dx value is the value at which x changes left / right
	   */
    public double getDx() {
        return dx;
    }

    /**
	   * This method sets the y value to the provided value
	   * @param dx The dx value is the value at which x changes left / right
	   */
    public void setDx(int dx) {
        this.dx = dx;
    }

    /**
	   * This method returns the dy value
	   * @return dy The dy value is the value at which y changes up / down
	   */
    public double getDy() {
        return dy;
    }

    /**
	   * This method sets the dy value to the provided value
	   * @param dy The dy value is the value at which y changes up / down
	   */
    public void setDy(double dy) {
        this.dy = dy;
    }
    
    /**
	   * This method returns the width value
	   * @return image.getWidth() The width value is the measurement or extent of something from side to side
	   */
    public double getWidth() {
    	return image.getWidth();
    }
    
    /**
	   * This method returns the height value
	   * @return image.getHeight() The height value is the measurement or extent of something from top to bottom
	   */
    public double getHeight() {
    	return image.getHeight();
    }

    /**
	   * This method returns the string of the image name
	   * @return imageName The imageName is a string that contains the route used to access an image
	   */
    public String getImageName() {
        return imageName;
    }

    /**
	   * This method sets the string of the imageName to the provided value
	   * @param imageName The imageName is a string that contains the route used to access an image
	   */
    public void setImageName(String imageName) {
        this.imageName = imageName;
    }
    
    /**
	   * This method sets the lives value to the provided value
	   * @return lives The lives value is an integer that displays how well the user is doing in the game
	   */
	public int getLives() {
		return lives;
	}
	
	/**
	   * This method gets the boundary of the object
	   * @return Rectangle2D The Rectangle2D is used to describe the bounds of an object
	   */
	public Rectangle2D getBoundary() {
		return new Rectangle2D(this.x, this.y, this.image.getWidth(), this.image.getHeight());
	}
	
	/**
	   * This method determines whether or not the object monkey collided with the banana object
	   * @param b The banana object
	   * @return collide Collide is a boolean that informs the program whether or not the user has collided with another object
	   */
	public boolean collisionBanana(Banana b) {
        boolean collide = b.getBoundary().intersects(this.getBoundary());
        return collide;
	}

	/**
	   * This method calls a method in the banana class that sends the banana to a new x and y coordinate
	   * @param banana The banana object
	   */
	public void hitBanana(Banana banana) {
		banana.newLocation();
	}
	
	/**
	   * This method determines whether or not the object monkey collided with the portal object
	   * @param p The portal object
	   * @return collide Collide is a boolean that informs the program whether or not the user has collided with another object
	   */
	public boolean collisionPortal(Portal p) {
        boolean collide = p.getBoundary().intersects(this.getBoundary());
        return collide;
	}
	
	/**
	   * This method determines whether or not the object monkey collided with the bad banana object
	   * @param bb The bad banana object
	   * @return collide Collide is a boolean that informs the program whether or not the user has collided with another object
	   */
	public boolean collisionBadBanana(badBanana bb) {
        boolean collide = bb.getBoundary().intersects(this.getBoundary());
        return collide;
	}
	
	/**
	   * This method calls a method in the bad banana class that sends the banana to a new x and y coordinate
	   * @param badBanana The badBanana object
	   */
	public void hitBadBanana(badBanana badBanana) {
		badBanana.newLocation();
	}
	
	/**
	   * This method determines whether or not the object monkey collided with any of the coconut objects
	   * @param c The coconut object
	   * @return collide Collide is a boolean that informs the program whether or not the user has collided with another object
	   */
	public boolean collisionCoconut(Coconut c) {
        boolean collide = c.getBoundary().intersects(this.getBoundary());
        return collide;
	}

	/**
	   * This method calls a method lose life that causes the lives integer to decrease
	   * @param coconut The coconut object
	   */
	public void hitCoconut(Coconut coconut) {
		loseLife(); 
	}
	
	/**
	   * This method determines whether or not the object monkey collided with any of the shoe objects
	   * @param s The shoe object
	   * @return collide Collide is a boolean that informs the program whether or not the user has collided with another object
	   */
	public boolean collisionShoe(Shoe s) {
        boolean collide = s.getBoundary().intersects(this.getBoundary());
        return collide;
	}
	
	/**
	   * This method gives the monkey a speed boost for four seconds
	   */
	public void speedBoost() {
		// timer
		new Thread (new Runnable() {
			public void run() {
				try {
					for (int i=4; i>=0; i--) {
						Thread.sleep(1000);
						increaseSpeed();
						if (i==0) {
							decreaseSpeed();
						}
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}).start();

	}
	
	private void increaseSpeed() {
		this.speed += 0.1;
	}
	
	private void decreaseSpeed() {
		this.speed = 2;		
	}

	/**
	   * This method decreases the lives integer by 1 and sends the monkey to new x and y coordinates
]	   */
	public void loseLife () {
		lives -= 1;
		this.x = (Math.random()*300) + 100;
		this.y = (Math.random()*300) + 100;
	}

	/**
	   * This method contains all code to move and display an image using user input
	   * from the arrow keys
	   * @param input The input ArrayList is an arrayList that contains user input that determines how the object moves
	   */
	public void move(ArrayList<String> input) {
		
		this.input = input;
		
		// for left button
	    if (this.input.contains(this.left) && this.x >= 0){
	       this.dx = -this.speed;
	    } else if (this.input.contains(this.right) && this.x <= 1000 - image.getWidth()){ // for right button
	       this.dx = this.speed;
	    } else {
	    	this.dx = 0; // sets it to 0 if nothing is pressed
	    }
	    
	    // for up button
	    if (this.input.contains(this.up) && this.y >= 0){
	       this.dy = -this.speed;
	    } else if (this.input.contains(this.down) && this.y <= 700 - image.getHeight()){ // for down button
	       this.dy = this.speed;
	    } else {
	    	this.dy = 0; // sets it to 0 if nothing is pressed
	    }
	    
	    // moves monkey
	    this.x += this.dx;
	    this.y += this.dy;

	    // redraws image
	    this.gc.drawImage(this.image, this.x, this.y);
	}
	
	/**
	   * This method sends the monkey to a new x and y coordinate
	   */
	public void teleport() {
		double newMonkeyX = (Math.random()*600) + 100;
		double newMonkeyY = (Math.random()*600) + 100;
		this.x = newMonkeyX;
		this.y = newMonkeyY;
	}
	
}
