package monkeyGame;
	
import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;


/**
* The Monkey Game program runs an exciting game where user's play as
* a monkey.  Their goal is to get as many banana's as they can before
* they run out of lives.
*
* @author  Natalie Assaad
* @version 1.0
* @since   2018-12-12
*/
public class Main extends Application {
	
	/**
	   * This method sets the basework for the startScreen
	   * @param primaryStage The primary stage
	   */
	@Override
	public void start(Stage primaryStage) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("startScreen.fxml"));
			BorderPane root = (BorderPane)loader.load();
			Scene scene = new Scene(root,600,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	   * This method launches the main method
	   * @param args The command line arguments
	   */
	public static void main(String[] args) {
		launch(args);
	}
	
	/**
	   * This method closes the primaryStage
	   */
	public static void quitWindow() {
		Platform.exit();
	}

}


